import sys, os
import program


def main():
    p = program.Program()
    p.run()